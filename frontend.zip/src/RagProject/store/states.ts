export interface AnotherState {
    rawdata: string
}

const state: AnotherState = {
    rawdata: '',
}

export default state