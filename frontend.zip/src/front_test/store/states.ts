export interface TestState {
    resultUrl: string
}

const state: TestState = {
    resultUrl: '',
}

export default state